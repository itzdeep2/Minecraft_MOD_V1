package net.minecraft.world.item;

import java.util.List;
import net.minecraft.nbt.CompoundTag;

public interface DyeableLeatherItem {
	String TAG_COLOR = "color";
	String TAG_DISPLAY = "display";
	int DEFAULT_LEATHER_COLOR = 10511680;

	default boolean hasCustomColor(ItemStack itemStack) {
		CompoundTag compoundTag = itemStack.getTagElement("display");
		return compoundTag != null && compoundTag.contains("color", 99);
	}

	default int getColor(ItemStack itemStack) {
		CompoundTag compoundTag = itemStack.getTagElement("display");
		return compoundTag != null && compoundTag.contains("color", 99) ? compoundTag.getInt("color") : 10511680;
	}

	default void clearColor(ItemStack itemStack) {
		CompoundTag compoundTag = itemStack.getTagElement("display");
		if (compoundTag != null && compoundTag.contains("color")) {
			compoundTag.remove("color");
		}
	}

	default void setColor(ItemStack itemStack, int i) {
		itemStack.getOrCreateTagElement("display").putInt("color", i);
	}

	static ItemStack dyeArmor(ItemStack itemStack, List<DyeItem> list) {
		ItemStack itemStack2 = ItemStack.EMPTY;
		int[] is = new int[3];
		int i = 0;
		int j = 0;
		DyeableLeatherItem dyeableLeatherItem = null;
		Item item = itemStack.getItem();
		if (item instanceof DyeableLeatherItem) {
			dyeableLeatherItem = (DyeableLeatherItem)item;
			itemStack2 = itemStack.copyWithCount(1);
			if (dyeableLeatherItem.hasCustomColor(itemStack)) {
				int k = dyeableLeatherItem.getColor(itemStack2);
				float f = (k >> 16 & 0xFF) / 255.0F;
				float g = (k >> 8 & 0xFF) / 255.0F;
				float h = (k & 0xFF) / 255.0F;
				i += (int)(Math.max(f, Math.max(g, h)) * 255.0F);
				is[0] += (int)(f * 255.0F);
				is[1] += (int)(g * 255.0F);
				is[2] += (int)(h * 255.0F);
				j++;
			}

			for (DyeItem dyeItem : list) {
				float[] fs = dyeItem.getDyeColor().getTextureDiffuseColors();
				int l = (int)(fs[0] * 255.0F);
				int m = (int)(fs[1] * 255.0F);
				int n = (int)(fs[2] * 255.0F);
				i += Math.max(l, Math.max(m, n));
				is[0] += l;
				is[1] += m;
				is[2] += n;
				j++;
			}
		}

		if (dyeableLeatherItem == null) {
			return ItemStack.EMPTY;
		}

		int k = is[0] / j;
		int o = is[1] / j;
		int p = is[2] / j;
		float h = (float)i / j;
		float q = Math.max(k, Math.max(o, p));
		k = (int)(k * h / q);
		o = (int)(o * h / q);
		p = (int)(p * h / q);
		int n = k;
		n = (n << 8) + o;
		n = (n << 8) + p;
		dyeableLeatherItem.setColor(itemStack2, n);
		return itemStack2;
	}
}

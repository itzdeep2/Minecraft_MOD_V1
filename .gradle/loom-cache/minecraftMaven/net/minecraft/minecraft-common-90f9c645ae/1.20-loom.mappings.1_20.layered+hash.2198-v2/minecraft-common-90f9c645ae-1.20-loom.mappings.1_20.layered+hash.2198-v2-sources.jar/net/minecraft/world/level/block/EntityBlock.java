package net.minecraft.world.level.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEventListener;
import org.jetbrains.annotations.Nullable;

public interface EntityBlock {
	@Nullable
	BlockEntity newBlockEntity(BlockPos blockPos, BlockState blockState);

	@Nullable
	default <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState blockState, BlockEntityType<T> blockEntityType) {
		return null;
	}

	@Nullable
	default <T extends BlockEntity> GameEventListener getListener(ServerLevel serverLevel, T blockEntity) {
		return blockEntity instanceof GameEventListener.Holder<?> holder ? holder.getListener() : null;
	}
}

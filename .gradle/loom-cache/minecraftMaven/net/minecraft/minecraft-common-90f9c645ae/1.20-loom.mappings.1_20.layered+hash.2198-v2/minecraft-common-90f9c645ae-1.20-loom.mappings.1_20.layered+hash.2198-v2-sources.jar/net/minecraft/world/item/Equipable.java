package net.minecraft.world.item;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public interface Equipable extends Vanishable {
	EquipmentSlot getEquipmentSlot();

	default SoundEvent getEquipSound() {
		return SoundEvents.ARMOR_EQUIP_GENERIC;
	}

	default InteractionResultHolder<ItemStack> swapWithEquipmentSlot(Item item, Level level, Player player, InteractionHand interactionHand) {
		ItemStack itemStack = player.getItemInHand(interactionHand);
		EquipmentSlot equipmentSlot = Mob.getEquipmentSlotForItem(itemStack);
		ItemStack itemStack2 = player.getItemBySlot(equipmentSlot);
		if (!EnchantmentHelper.hasBindingCurse(itemStack2) && !ItemStack.matches(itemStack, itemStack2)) {
			if (!level.isClientSide()) {
				player.awardStat(Stats.ITEM_USED.get(item));
			}

			ItemStack itemStack3 = itemStack2.isEmpty() ? itemStack : itemStack2.copyAndClear();
			ItemStack itemStack4 = itemStack.copyAndClear();
			player.setItemSlot(equipmentSlot, itemStack4);
			return InteractionResultHolder.sidedSuccess(itemStack3, level.isClientSide());
		} else {
			return InteractionResultHolder.fail(itemStack);
		}
	}

	@Nullable
	static Equipable get(ItemStack itemStack) {
		if (itemStack.getItem() instanceof Equipable equipable) {
			return equipable;
		} else {
			return itemStack.getItem() instanceof BlockItem blockItem && blockItem.getBlock() instanceof Equipable equipable2 ? equipable2 : null;
		}
	}
}

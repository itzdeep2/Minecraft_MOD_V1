package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.dto.Backup;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;

@Environment(EnvType.CLIENT)
public class RealmsBackupInfoScreen extends RealmsScreen {
	private static final Component UNKNOWN = Component.translatable("mco.backup.unknown");
	private final Screen lastScreen;
	final Backup backup;
	private RealmsBackupInfoScreen.BackupInfoList backupInfoList;

	public RealmsBackupInfoScreen(Screen screen, Backup backup) {
		super(Component.translatable("mco.backup.info.title"));
		this.lastScreen = screen;
		this.backup = backup;
	}

	@Override
	public void tick() {
	}

	@Override
	public void init() {
		this.addRenderableWidget(
			Button.builder(CommonComponents.GUI_BACK, button -> this.minecraft.setScreen(this.lastScreen))
				.bounds(this.width / 2 - 100, this.height / 4 + 120 + 24, 200, 20)
				.build()
		);
		this.backupInfoList = new RealmsBackupInfoScreen.BackupInfoList(this.minecraft);
		this.addWidget(this.backupInfoList);
		this.magicalSpecialHackyFocus(this.backupInfoList);
	}

	@Override
	public boolean keyPressed(int i, int j, int k) {
		if (i == 256) {
			this.minecraft.setScreen(this.lastScreen);
			return true;
		} else {
			return super.keyPressed(i, j, k);
		}
	}

	@Override
	public void render(GuiGraphics guiGraphics, int i, int j, float f) {
		this.renderBackground(guiGraphics);
		this.backupInfoList.render(guiGraphics, i, j, f);
		guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 10, 16777215);
		super.render(guiGraphics, i, j, f);
	}

	Component checkForSpecificMetadata(String string, String string2) {
		String string3 = string.toLowerCase(Locale.ROOT);
		if (string3.contains("game") && string3.contains("mode")) {
			return this.gameModeMetadata(string2);
		} else {
			return (Component)(string3.contains("game") && string3.contains("difficulty") ? this.gameDifficultyMetadata(string2) : Component.literal(string2));
		}
	}

	private Component gameDifficultyMetadata(String string) {
		try {
			return RealmsSlotOptionsScreen.DIFFICULTIES.get(Integer.parseInt(string)).getDisplayName();
		} catch (Exception exception) {
			return UNKNOWN;
		}
	}

	private Component gameModeMetadata(String string) {
		try {
			return RealmsSlotOptionsScreen.GAME_MODES.get(Integer.parseInt(string)).getShortDisplayName();
		} catch (Exception exception) {
			return UNKNOWN;
		}
	}

	@Environment(EnvType.CLIENT)
	class BackupInfoList extends ObjectSelectionList<RealmsBackupInfoScreen.BackupInfoListEntry> {
		public BackupInfoList(Minecraft minecraft) {
			super(minecraft, RealmsBackupInfoScreen.this.width, RealmsBackupInfoScreen.this.height, 32, RealmsBackupInfoScreen.this.height - 64, 36);
			this.setRenderSelection(false);
			if (RealmsBackupInfoScreen.this.backup.changeList != null) {
				RealmsBackupInfoScreen.this.backup
					.changeList
					.forEach((string, string2) -> this.addEntry(RealmsBackupInfoScreen.this.new BackupInfoListEntry(string, string2)));
			}
		}
	}

	@Environment(EnvType.CLIENT)
	class BackupInfoListEntry extends ObjectSelectionList.Entry<RealmsBackupInfoScreen.BackupInfoListEntry> {
		private static final Component TEMPLATE_NAME = Component.translatable("mco.backup.entry.templateName");
		private static final Component GAME_DIFFICULTY = Component.translatable("mco.backup.entry.gameDifficulty");
		private static final Component NAME = Component.translatable("mco.backup.entry.name");
		private static final Component GAME_SERVER_VERSION = Component.translatable("mco.backup.entry.gameServerVersion");
		private static final Component UPLOADED = Component.translatable("mco.backup.entry.uploaded");
		private static final Component ENABLED_PACK = Component.translatable("mco.backup.entry.enabledPack");
		private static final Component DESCRIPTION = Component.translatable("mco.backup.entry.description");
		private static final Component GAME_MODE = Component.translatable("mco.backup.entry.gameMode");
		private static final Component SEED = Component.translatable("mco.backup.entry.seed");
		private static final Component WORLD_TYPE = Component.translatable("mco.backup.entry.worldType");
		private static final Component UNDEFINED = Component.translatable("mco.backup.entry.undefined");
		private final String key;
		private final String value;

		public BackupInfoListEntry(String string, String string2) {
			this.key = string;
			this.value = string2;
		}

		@Override
		public void render(GuiGraphics guiGraphics, int i, int j, int k, int l, int m, int n, int o, boolean bl, float f) {
			guiGraphics.drawString(RealmsBackupInfoScreen.this.font, this.translateKey(this.key), k, j, 10526880);
			guiGraphics.drawString(RealmsBackupInfoScreen.this.font, RealmsBackupInfoScreen.this.checkForSpecificMetadata(this.key, this.value), k, j + 12, 16777215);
		}

		private Component translateKey(String string) {
			return switch (string) {
				case "template_name" -> TEMPLATE_NAME;
				case "game_difficulty" -> GAME_DIFFICULTY;
				case "name" -> NAME;
				case "game_server_version" -> GAME_SERVER_VERSION;
				case "uploaded" -> UPLOADED;
				case "enabled_pack" -> ENABLED_PACK;
				case "description" -> DESCRIPTION;
				case "game_mode" -> GAME_MODE;
				case "seed" -> SEED;
				case "world_type" -> WORLD_TYPE;
				default -> UNDEFINED;
			};
		}

		@Override
		public Component getNarration() {
			return Component.translatable("narrator.select", new Object[]{this.key + " " + this.value});
		}
	}
}

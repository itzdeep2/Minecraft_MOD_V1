package com.mojang.realmsclient.dto;

import com.google.common.collect.Lists;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.slf4j.Logger;

@Environment(EnvType.CLIENT)
public class BackupList extends ValueObject {
	private static final Logger LOGGER = LogUtils.getLogger();
	public List<Backup> backups;

	public static BackupList parse(String string) {
		JsonParser jsonParser = new JsonParser();
		BackupList backupList = new BackupList();
		backupList.backups = Lists.newArrayList();

		try {
			JsonElement jsonElement = jsonParser.parse(string).getAsJsonObject().get("backups");
			if (jsonElement.isJsonArray()) {
				Iterator<JsonElement> iterator = jsonElement.getAsJsonArray().iterator();

				while (iterator.hasNext()) {
					backupList.backups.add(Backup.parse(iterator.next()));
				}
			}
		} catch (Exception exception) {
			LOGGER.error("Could not parse BackupList: {}", exception.getMessage());
		}

		return backupList;
	}
}

package net.minecraft.client.gui.screens.recipebook;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.recipebook.PlaceRecipe;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.inventory.AbstractFurnaceMenu;
import net.minecraft.world.inventory.RecipeBookMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class OverlayRecipeComponent implements Renderable, GuiEventListener {
	static final ResourceLocation RECIPE_BOOK_LOCATION = new ResourceLocation("textures/gui/recipe_book.png");
	private static final int MAX_ROW = 4;
	private static final int MAX_ROW_LARGE = 5;
	private static final float ITEM_RENDER_SCALE = 0.375F;
	public static final int BUTTON_SIZE = 25;
	private final List<OverlayRecipeComponent.OverlayRecipeButton> recipeButtons = Lists.newArrayList();
	private boolean isVisible;
	private int x;
	private int y;
	private Minecraft minecraft;
	private RecipeCollection collection;
	@Nullable
	private Recipe<?> lastRecipeClicked;
	float time;
	boolean isFurnaceMenu;

	public void init(Minecraft minecraft, RecipeCollection recipeCollection, int i, int j, int k, int l, float f) {
		this.minecraft = minecraft;
		this.collection = recipeCollection;
		if (minecraft.player.containerMenu instanceof AbstractFurnaceMenu) {
			this.isFurnaceMenu = true;
		}

		boolean bl = minecraft.player.getRecipeBook().isFiltering((RecipeBookMenu)minecraft.player.containerMenu);
		List<Recipe<?>> list = recipeCollection.getDisplayRecipes(true);
		List<Recipe<?>> list2 = bl ? Collections.emptyList() : recipeCollection.getDisplayRecipes(false);
		int m = list.size();
		int n = m + list2.size();
		int o = n <= 16 ? 4 : 5;
		int p = (int)Math.ceil((float)n / o);
		this.x = i;
		this.y = j;
		float g = this.x + Math.min(n, o) * 25;
		float h = k + 50;
		if (g > h) {
			this.x = (int)(this.x - f * (int)((g - h) / f));
		}

		float q = this.y + p * 25;
		float r = l + 50;
		if (q > r) {
			this.y = (int)(this.y - f * Mth.ceil((q - r) / f));
		}

		float s = this.y;
		float t = l - 100;
		if (s < t) {
			this.y = (int)(this.y - f * Mth.ceil((s - t) / f));
		}

		this.isVisible = true;
		this.recipeButtons.clear();

		for (int u = 0; u < n; u++) {
			boolean bl2 = u < m;
			Recipe<?> recipe = bl2 ? list.get(u) : list2.get(u - m);
			int v = this.x + 4 + 25 * (u % o);
			int w = this.y + 5 + 25 * (u / o);
			if (this.isFurnaceMenu) {
				this.recipeButtons.add(new OverlayRecipeComponent.OverlaySmeltingRecipeButton(v, w, recipe, bl2));
			} else {
				this.recipeButtons.add(new OverlayRecipeComponent.OverlayRecipeButton(v, w, recipe, bl2));
			}
		}

		this.lastRecipeClicked = null;
	}

	public RecipeCollection getRecipeCollection() {
		return this.collection;
	}

	@Nullable
	public Recipe<?> getLastRecipeClicked() {
		return this.lastRecipeClicked;
	}

	@Override
	public boolean mouseClicked(double d, double e, int i) {
		if (i != 0) {
			return false;
		}

		for (OverlayRecipeComponent.OverlayRecipeButton overlayRecipeButton : this.recipeButtons) {
			if (overlayRecipeButton.mouseClicked(d, e, i)) {
				this.lastRecipeClicked = overlayRecipeButton.recipe;
				return true;
			}
		}

		return false;
	}

	@Override
	public boolean isMouseOver(double d, double e) {
		return false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int i, int j, float f) {
		if (this.isVisible) {
			this.time += f;
			RenderSystem.enableBlend();
			guiGraphics.pose().pushPose();
			guiGraphics.pose().translate(0.0F, 0.0F, 1000.0F);
			int k = this.recipeButtons.size() <= 16 ? 4 : 5;
			int l = Math.min(this.recipeButtons.size(), k);
			int m = Mth.ceil((float)this.recipeButtons.size() / k);
			int n = 4;
			guiGraphics.blitNineSliced(RECIPE_BOOK_LOCATION, this.x, this.y, l * 25 + 8, m * 25 + 8, 4, 32, 32, 82, 208);
			RenderSystem.disableBlend();

			for (OverlayRecipeComponent.OverlayRecipeButton overlayRecipeButton : this.recipeButtons) {
				overlayRecipeButton.render(guiGraphics, i, j, f);
			}

			guiGraphics.pose().popPose();
		}
	}

	public void setVisible(boolean bl) {
		this.isVisible = bl;
	}

	public boolean isVisible() {
		return this.isVisible;
	}

	@Override
	public void setFocused(boolean bl) {
	}

	@Override
	public boolean isFocused() {
		return false;
	}

	@Environment(EnvType.CLIENT)
	class OverlayRecipeButton extends AbstractWidget implements PlaceRecipe<Ingredient> {
		final Recipe<?> recipe;
		private final boolean isCraftable;
		protected final List<OverlayRecipeComponent.OverlayRecipeButton.Pos> ingredientPos = Lists.newArrayList();

		public OverlayRecipeButton(int i, int j, Recipe<?> recipe, boolean bl) {
			super(i, j, 200, 20, CommonComponents.EMPTY);
			this.width = 24;
			this.height = 24;
			this.recipe = recipe;
			this.isCraftable = bl;
			this.calculateIngredientsPositions(recipe);
		}

		protected void calculateIngredientsPositions(Recipe<?> recipe) {
			this.placeRecipe(3, 3, -1, recipe, recipe.getIngredients().iterator(), 0);
		}

		@Override
		public void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
			this.defaultButtonNarrationText(narrationElementOutput);
		}

		public void addItemToSlot(Iterator<Ingredient> iterator, int i, int j, int k, int l) {
			ItemStack[] itemStacks = iterator.next().getItems();
			if (itemStacks.length != 0) {
				this.ingredientPos.add(new OverlayRecipeComponent.OverlayRecipeButton.Pos(3 + l * 7, 3 + k * 7, itemStacks));
			}
		}

		@Override
		public void renderWidget(GuiGraphics guiGraphics, int i, int j, float f) {
			int k = 152;
			if (!this.isCraftable) {
				k += 26;
			}

			int l = OverlayRecipeComponent.this.isFurnaceMenu ? 130 : 78;
			if (this.isHoveredOrFocused()) {
				l += 26;
			}

			guiGraphics.blit(OverlayRecipeComponent.RECIPE_BOOK_LOCATION, this.getX(), this.getY(), k, l, this.width, this.height);
			guiGraphics.pose().pushPose();
			guiGraphics.pose().translate(this.getX() + 2, this.getY() + 2, 150.0);

			for (OverlayRecipeComponent.OverlayRecipeButton.Pos pos : this.ingredientPos) {
				guiGraphics.pose().pushPose();
				guiGraphics.pose().translate(pos.x, pos.y, 0.0);
				guiGraphics.pose().scale(0.375F, 0.375F, 1.0F);
				guiGraphics.pose().translate(-8.0, -8.0, 0.0);
				if (pos.ingredients.length > 0) {
					guiGraphics.renderItem(pos.ingredients[Mth.floor(OverlayRecipeComponent.this.time / 30.0F) % pos.ingredients.length], 0, 0);
				}

				guiGraphics.pose().popPose();
			}

			guiGraphics.pose().popPose();
		}

		@Environment(EnvType.CLIENT)
		protected class Pos {
			public final ItemStack[] ingredients;
			public final int x;
			public final int y;

			public Pos(int i, int j, ItemStack[] itemStacks) {
				this.x = i;
				this.y = j;
				this.ingredients = itemStacks;
			}
		}
	}

	@Environment(EnvType.CLIENT)
	class OverlaySmeltingRecipeButton extends OverlayRecipeComponent.OverlayRecipeButton {
		public OverlaySmeltingRecipeButton(int i, int j, Recipe<?> recipe, boolean bl) {
			super(i, j, recipe, bl);
		}

		@Override
		protected void calculateIngredientsPositions(Recipe<?> recipe) {
			ItemStack[] itemStacks = ((Ingredient)recipe.getIngredients().get(0)).getItems();
			this.ingredientPos.add(new OverlayRecipeComponent.OverlayRecipeButton.Pos(10, 10, itemStacks));
		}
	}
}
